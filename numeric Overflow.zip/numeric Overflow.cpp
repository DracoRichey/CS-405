#include <iostream>
#include <limits>
#include <utility>
#include <type_traits>
#include <cmath>

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// Secure version: detects and prevents overflow/underflow
/// Returns:
///   pair.first  -> last safe result
///   pair.second -> true if safe, false if overflow/underflow prevented
/// </summary>
template <typename T>
std::pair<T, bool> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Integer overflow / underflow detection
        if constexpr (std::is_integral_v<T>)
        {
            if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
                return { result, false }; // overflow prevented

            if (increment < 0 && result < std::numeric_limits<T>::min() - increment)
                return { result, false }; // underflow prevented
        }

        result += increment;

        // Floating point overflow detection
        if constexpr (std::is_floating_point_v<T>)
        {
            if (!std::isfinite(result))
                return { result, false };
        }
    }

    return { result, true };
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (decrement * steps)
/// Secure version: detects and prevents overflow/underflow
/// </summary>
template <typename T>
std::pair<T, bool> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Integer overflow / underflow detection
        if constexpr (std::is_integral_v<T>)
        {
            if (decrement > 0 && result < std::numeric_limits<T>::min() + decrement)
                return { result, false }; // underflow prevented

            if (decrement < 0 && result > std::numeric_limits<T>::max() + decrement)
                return { result, false }; // overflow prevented
        }

        result -= decrement;

        // Floating point overflow detection
        if constexpr (std::is_floating_point_v<T>)
        {
            if (!std::isfinite(result))
                return { result, false };
        }
    }

    return { result, true };
}

/// <summary>
/// Test overflow behavior
/// </summary>
template <typename T>
void test_overflow()
{
    T start = std::numeric_limits<T>::max() - 1;
    T increment = 1;
    unsigned long int steps = 1;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    auto result = add_numbers<T>(start, increment, steps);
    std::cout << "Overflow: " << (result.second ? "false" : "true")
        << " Result: " << +result.first << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << steps + 1 << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);
    std::cout << "Overflow: " << (result.second ? "false" : "true")
        << " Result: " << +result.first << std::endl;
}

/// <summary>
/// Test underflow behavior
/// </summary>
template <typename T>
void test_underflow()
{
    T start = std::numeric_limits<T>::min() + 1;
    T decrement = 1;
    unsigned long int steps = 1;

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps);
    std::cout << "Underflow: " << (result.second ? "false" : "true")
        << " Result: " << +result.first << std::endl;

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << steps + 1 << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    std::cout << "Underflow: " << (result.second ? "false" : "true")
        << " Result: " << +result.first << std::endl;
}

int main()
{
    std::cout << "Testing INT overflow\n";
    test_overflow<int>();

    std::cout << "\nTesting INT underflow\n";
    test_underflow<int>();

    std::cout << "\nTesting FLOAT overflow\n";
    test_overflow<float>();

    std::cout << "\nTesting FLOAT underflow\n";
    test_underflow<float>();

    return 0;
}
